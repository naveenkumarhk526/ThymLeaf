package com.prabhu.entityController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.prabhu.Iservice.ServiceInterface;
import com.prabhu.entity.Entity;

@org.springframework.stereotype.Controller
@RequestMapping("/student")
public class Controller {
	@Autowired
	private ServiceInterface service;
	@GetMapping("/register")
	public String showData() {
		return "Register";
	}
	@PostMapping("/save")
	public String saveData(@ModelAttribute Entity ent,Model model) {
		Integer id=service.saveData(ent);
		model.addAttribute("message","Sucessfully Student "+id+"Inserted");
		return "Register";
	}
	@GetMapping("/all")
	public String allData(@RequestParam(required = false) String message, Model model) {
		List<Entity> list=service.getAllStudents();
		model.addAttribute("list",list);
		model.addAttribute("message",message);
		return "Data";
	}
	@GetMapping("/delete")
	public String deleteData(@RequestParam Integer id,Model model) {
		service.deleteStudent(id);
		model.addAttribute("message","Deleted Student "+id+"Sucessfully");
		return "redirect:/all";
	}
	@GetMapping("/edit")
	public String editStudent(Integer id,Model model) {
		Entity ent=service.getOneStudent(id);
		model.addAttribute("entity",ent);
		return "Edit";
	}
	@PostMapping("/update")
	public String updateStudent(@ModelAttribute Entity ent,RedirectAttributes attribute) {
		service.updateStudent(ent);
		attribute.addAttribute("message","Sucessfulley Student"+ent.getId()+"Updated");
		return "redirect:all";
	}
	@GetMapping("/checkCode")
    public ResponseEntity<Boolean> checkCode(@RequestParam String phone) {
        boolean isCodeAvailable = service.isCodeAvailable(phone);
        return ResponseEntity.ok(isCodeAvailable);
    }
	@GetMapping("/checkMail")
    public ResponseEntity<Boolean> checkMail(@RequestParam String email) {
        boolean isMailAvailable = service.isMailAvailable(email);
        return ResponseEntity.ok(isMailAvailable);
    }
}
