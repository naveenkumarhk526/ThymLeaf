package com.prabhu.Iservice;

import java.util.List;

import com.prabhu.entity.Entity;

public interface ServiceInterface {
	Integer saveData(Entity ent);
	List<Entity> getAllStudents();
	Entity getOneStudent(Integer id);
	void deleteStudent(Integer id);
	void updateStudent(Entity ent);
	boolean isCodeAvailable(String phone);
	boolean isMailAvailable(String email);
}
