package com.prabhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProject3UsingThymleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProject3UsingThymleafApplication.class, args);
	}

}
