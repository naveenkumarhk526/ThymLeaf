package com.prabhu.ServiceImple;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prabhu.Iservice.ServiceInterface;
import com.prabhu.entity.Entity;
import com.prabhu.repo.Repo;
@Service
public class ServiceImplementation implements ServiceInterface{
	@Autowired
	private Repo repo;
	@Override
	public Integer saveData(Entity ent) {
		return repo.save(ent).getId();
	}

	@Override
	public List<Entity> getAllStudents() {
		return repo.findAll();
	}

	@Override
	public Entity getOneStudent(Integer id) {
		return repo.findById(id).get();
	}

	@Override
	public void deleteStudent(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public void updateStudent(Entity ent) {
		repo.save(ent);
	}

	@Override
	public boolean isCodeAvailable(String phone) {
		return !repo.existsByPhone(phone);
	}

	@Override
	public boolean isMailAvailable(String email) {
		// TODO Auto-generated method stub
		return !repo.existsByEmail(email);
	}

}
