package com.prabhu.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prabhu.entity.Entity;

public interface Repo extends JpaRepository<Entity, Integer>{
	 boolean existsByPhone(String phone);

	boolean existsByEmail(String email);
}
